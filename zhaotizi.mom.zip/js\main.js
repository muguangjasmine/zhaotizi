// 找梯子指南 (zhaotizi.mom) JavaScript Interactivity

document.addEventListener('DOMContentLoaded', () => {
  // Mobile Nav Toggle
  const mobileToggle = document.getElementById('mobileMenuToggle');
  const mobileDrawer = document.getElementById('mobileNavDrawer');
  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', () => {
      mobileDrawer.classList.toggle('open');
    });
  }

  // FAQ Accordion
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question');
    if (btn) {
      btn.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        // Close others in same container if desired, or toggle
        item.classList.toggle('active', !isActive);
      });
    }
  });

  // Copy Coupon Code
  const copyBtns = document.querySelectorAll('.copy-btn');
  copyBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const code = btn.getAttribute('data-code');
      if (code) {
        navigator.clipboard.writeText(code).then(() => {
          const originalText = btn.textContent;
          btn.textContent = '已复制!';
          btn.style.backgroundColor = '#ecfdf5';
          btn.style.color = '#065f46';
          setTimeout(() => {
            btn.textContent = originalText;
            btn.style.backgroundColor = '';
            btn.style.color = '';
          }, 2000);
        }).catch(() => {
          alert('优惠码：' + code);
        });
      }
    });
  });

  // Search Modal
  const searchModal = document.getElementById('searchModal');
  const openSearchBtns = document.querySelectorAll('.open-search-modal');
  const closeSearchBtn = document.getElementById('closeSearchModal');

  function openSearch() {
    if (searchModal) {
      searchModal.classList.add('open');
      const input = searchModal.querySelector('.pagefind-ui__search-input');
      if (input) input.focus();
    }
  }

  function closeSearch() {
    if (searchModal) {
      searchModal.classList.remove('open');
    }
  }

  openSearchBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openSearch();
    });
  });

  if (closeSearchBtn) {
    closeSearchBtn.addEventListener('click', closeSearch);
  }

  if (searchModal) {
    searchModal.addEventListener('click', (e) => {
      if (e.target === searchModal) {
        closeSearch();
      }
    });
  }

  // Header quick search trigger
  const headerSearchInput = document.getElementById('headerSearchInput');
  if (headerSearchInput) {
    headerSearchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const val = headerSearchInput.value.trim();
        openSearch();
        setTimeout(() => {
          const pfInput = document.querySelector('.pagefind-ui__search-input');
          if (pfInput && val) {
            pfInput.value = val;
            pfInput.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }, 100);
      }
    });
    headerSearchInput.addEventListener('click', () => {
      openSearch();
    });
  }

  // TOC active scrollspy
  const tocLinks = document.querySelectorAll('.toc-nav a');
  if (tocLinks.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          tocLinks.forEach(link => {
            if (link.getAttribute('href') === `#${id}`) {
              link.classList.add('active');
            } else {
              link.classList.remove('active');
            }
          });
        }
      });
    }, { rootMargin: '0px 0px -70% 0px' });

    document.querySelectorAll('.article-body h2, .article-body h3').forEach(h => {
      observer.observe(h);
    });
  }
});
